#include "window.h"

extern void corrector(Window& w);
